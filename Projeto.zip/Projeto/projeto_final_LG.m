%%Project Work 
% *SEITSF 2020/2021*
%
%
% Trabalho realizado por:
%   Francisco Carvalho n�90069,
%   Jo�o Marques n�90102,
%   Nuno Cunha n�98485
%  
%% Taking the data from -csv files from the PVGIS TOOL:

clear all, close all, clc

data_2016 = readtable('Timeseries_41.944_45.798_SA_33deg_0deg_2016_2016.csv');

%% ESCOLHA N�MERO DE PAINEIS - INPUT -
%$$$$$$$$$$$$$$$$$$$$$
%$$$$$$$$$$$$$$$$$$$$$
%$$$$$$$$$$$$$$$$$$$$$
N_paineis_total = 136;
%$$$$$$$$$$$$$$$$$$$$$
%$$$$$$$$$$$$$$$$$$$$$
%$$$$$$$$$$$$$$$$$$$$$
%$$$$$$$$$$$$$$$$$$$$$
%% FOR THE LG NEON R PRIME 370 W- MONO

%caracteristicas do painel:
G_NOCT = 800;
Tamb_NOCT = 20;
Tpv_NOCT = 44;
Pmax_NOCT = 279;
temp_coef_Pmax = -0.003;
Vmp_NOCT = 37.1;
temp_coef_V = -0.0024;



%INICIALIZA��O DE VARI�VEIS:
%variaveis de min e max para a potencia gerada diaria de um determinado mes
MAX_Pmax_1 = -1;
MIN_Pmax_1 = 100000;
MAX_Pmax_2 = -1;
MIN_Pmax_2 = 100000;
MAX_Pmax_3 = -1;
MIN_Pmax_3 = 100000;
MAX_Pmax_4 = -1;
MIN_Pmax_4 = 100000;
MAX_Pmax_5 = -1;
MIN_Pmax_5 = 100000;
MAX_Pmax_6 = -1;
MIN_Pmax_6 = 100000;
MAX_Pmax_7 = -1;
MIN_Pmax_7 = 100000;
MAX_Pmax_8 = -1;
MIN_Pmax_8 = 100000;
MAX_Pmax_9 = -1;
MIN_Pmax_9 = 100000;
MAX_Pmax_10 = -1;
MIN_Pmax_10 = 100000;
MAX_Pmax_11 = -1;
MIN_Pmax_11 = 100000;
MAX_Pmax_12 = -1;
MIN_Pmax_12 = 100000;

MAX_G_1 = -1;
MIN_G_1 = 1000000000;
MAX_G_2 = -1;
MIN_G_2 = 1000000000;
MAX_G_3 = -1;
MIN_G_3 = 1000000000;
MAX_G_4 = -1;
MIN_G_4 = 1000000000;
MAX_G_5 = -1;
MIN_G_5 = 1000000000;
MAX_G_6 = -1;
MIN_G_6 = 1000000000;
MAX_G_7 = -1;
MIN_G_7 = 1000000000;
MAX_G_8 = -1;
MIN_G_8 = 1000000000;
MAX_G_9 = -1;
MIN_G_9 = 1000000000;
MAX_G_10 = -1;
MIN_G_10 = 1000000000;
MAX_G_11 = -1;
MIN_G_11 = 1000000000;
MAX_G_12 = -1;
MIN_G_12 = 1000000000;


MAX_Tpv_1 = -1;
MIN_Tpv_1 = 100000;
MAX_Tpv_2 = -1;
MIN_Tpv_2 = 100000;
MAX_Tpv_3 = -1;
MIN_Tpv_3 = 100000;
MAX_Tpv_4 = -1;
MIN_Tpv_4 = 100000;
MAX_Tpv_5 = -1;
MIN_Tpv_5 = 100000;
MAX_Tpv_6 = -1;
MIN_Tpv_6 = 100000;
MAX_Tpv_7 = -1;
MIN_Tpv_7 = 100000;
MAX_Tpv_8 = -1;
MIN_Tpv_8 = 100000;
MAX_Tpv_9 = -1;
MIN_Tpv_9 = 100000;
MAX_Tpv_10 = -1;
MIN_Tpv_10 = 100000;
MAX_Tpv_11 = -1;
MIN_Tpv_11 = 100000;
MAX_Tpv_12 = -1;
MIN_Tpv_12 = 100000;



MAX_Tamb_1 = -1;
MIN_Tamb_1 = 100000;
MAX_Tamb_2 = -1;
MIN_Tamb_2 = 100000;
MAX_Tamb_3 = -1;
MIN_Tamb_3 = 100000;
MAX_Tamb_4 = -1;
MIN_Tamb_4 = 100000;
MAX_Tamb_5 = -1;
MIN_Tamb_5 = 100000;
MAX_Tamb_6 = -1;
MIN_Tamb_6 = 100000;
MAX_Tamb_7 = -1;
MIN_Tamb_7 = 100000;
MAX_Tamb_8 = -1;
MIN_Tamb_8 = 100000;
MAX_Tamb_9 = -1;
MIN_Tamb_9 = 100000;
MAX_Tamb_10 = -1;
MIN_Tamb_10 = 100000;
MAX_Tamb_11 = -1;
MIN_Tamb_11 = 100000;
MAX_Tamb_12 = -1;
MIN_Tamb_12 = 100000;

%min e max de Vmp e Imp
MAX_Vmp = -1;
MIN_Vmp = 100000;
MAX_Imp = -1;
MIN_Imp = 100000;

%melhores dias de cada m�s
best_janeiro = 0;
best_fevereiro = 0;
best_marco = 0;
best_abril = 0;
best_maio = 0;
best_junho = 0;
best_julho = 0;
best_agosto = 0;
best_setembro = 0;
best_outubro = 0;
best_novembro = 0;
best_dezembro = 0;


%piores dias de cada m�s
worst_janeiro = 0;
worst_fevereiro = 0;
worst_marco = 0;
worst_abril = 0;
worst_maio = 0;
worst_junho = 0;
worst_julho = 0;
worst_agosto = 0;
worst_setembro = 0;
worst_outubro = 0;
worst_novembro = 0;
worst_dezembro = 0;






Cum_Pmax=0;
Tpv_2016 = zeros(1,8773);
Pmax_2016 = zeros(1,8773);
Vmp_2016 = zeros(1,8773);
P_prod_diaria = zeros(366,1);
H_prod_diaria = zeros(366,1);
counter_horas_prod_dia=0;
k = 1;

for i=1:8783

chr = cell2mat(convertStringsToChars(data_2016.time(i)));%ver que m�s nos encontramos
chr_mes = chr(5:6);
n = str2num(['uint8(',chr_mes,')']); 

if n==1
%---------------
%JANEIRO
%---------------

%ver dia atual
chr_dia = chr(7:8);
dia = str2num(['uint8(',chr_dia,')']);

    
G_global_hora = data_2016.G_i_(i);
if G_global_hora>MAX_G_1
    MAX_G_1 = G_global_hora;
end
if G_global_hora<MIN_G_1 && G_global_hora>0 
    MIN_G_1 = G_global_hora;
end

Tamb_hora = data_2016.T2m(i);
if Tamb_hora>MAX_Tamb_1
    MAX_Tamb_1 = Tamb_hora;
end
if Tamb_hora<MIN_Tamb_1 && G_global_hora>0 
    MIN_Tamb_1 = Tamb_hora;
end

Tpv_hora = Tamb_hora + (G_global_hora/G_NOCT)*(Tpv_NOCT-Tamb_NOCT);
Tpv_2016(i) = Tpv_hora;
if Tpv_hora>MAX_Tpv_1
    MAX_Tpv_1 = Tpv_hora;
end    
if Tpv_hora<MIN_Tpv_1 && G_global_hora>0 
    MIN_Tpv_1 = Tpv_hora;
end

Pmax_hora = Pmax_NOCT*(G_global_hora/G_NOCT).*(1-temp_coef_Pmax*(Tpv_hora-Tpv_NOCT));
Pmax_2016(i) = Pmax_hora;

Vmp_hora = Vmp_NOCT.*(1-temp_coef_V*(Tpv_hora-Tpv_NOCT));
Vmp_2016(i) = Vmp_hora;

if Vmp_hora > MAX_Vmp
    MAX_Vmp = Vmp_hora;
end    
if Vmp_hora < MIN_Vmp
    MIN_Vmp = Vmp_hora;
end

Imp_hora = Pmax_hora/Vmp_hora;
Imp_2016(i) = Imp_hora;

if Imp_hora > MAX_Imp && G_global_hora>0 
    MAX_Imp = Imp_hora;
end    
if Imp_hora < MIN_Imp && G_global_hora>0 
    MIN_Imp = Imp_hora;
end

%ver dia seguinte 
chr_aux = cell2mat(convertStringsToChars(data_2016.time(i+1)));
chr_dia_seguinte = chr_aux(7:8);
dia_seguinte = str2num(['uint8(',chr_dia_seguinte,')']);

if dia==dia_seguinte
    Cum_Pmax = Cum_Pmax + Pmax_hora;
    if(Pmax_hora>0)
    counter_horas_prod_dia = counter_horas_prod_dia+1;
    end
else
    Cum_Pmax = Cum_Pmax + Pmax_hora;
    if Cum_Pmax > MAX_Pmax_1
        MAX_Pmax_1 = Cum_Pmax;
        best_janeiro = dia;
    end    
    if Cum_Pmax < MIN_Pmax_1
        MIN_Pmax_1 = Cum_Pmax;
        worst_janeiro = dia;
    end
    if(Pmax_hora>0)
    counter_horas_prod_dia = counter_horas_prod_dia+1;
    end
    H_prod_diaria(k) = counter_horas_prod_dia;
    P_prod_diaria(k) = Cum_Pmax;
    k = k+1;
    Cum_Pmax=0; 
    counter_horas_prod_dia=0;
end   
end





if n==2
%---------------
%FEVEREIRO
%---------------

%ver dia atual
chr_dia = chr(7:8);
dia = str2num(['uint8(',chr_dia,')']);

    
G_global_hora = data_2016.G_i_(i);
if G_global_hora>MAX_G_2
    MAX_G_2 = G_global_hora;
end
if G_global_hora<MIN_G_2 && G_global_hora>0 
    MIN_G_2 = G_global_hora;
end

Tamb_hora = data_2016.T2m(i);
if Tamb_hora>MAX_Tamb_2
    MAX_Tamb_2 = Tamb_hora;
elseif Tamb_hora<MIN_Tamb_2 && G_global_hora>0 
    MIN_Tamb_2 = Tamb_hora;
end

Tpv_hora = Tamb_hora + (G_global_hora/G_NOCT)*(Tpv_NOCT-Tamb_NOCT);
Tpv_2016(i) = Tpv_hora;
if Tpv_hora>MAX_Tpv_2
    MAX_Tpv_2 = Tpv_hora;
elseif Tpv_hora<MIN_Tpv_2 && G_global_hora>0
    MIN_Tpv_2 = Tpv_hora;
end

Pmax_hora = Pmax_NOCT*(G_global_hora/G_NOCT).*(1-temp_coef_Pmax*(Tpv_hora-Tpv_NOCT));
Pmax_2016(i) = Pmax_hora;

Vmp_hora = Vmp_NOCT.*(1-temp_coef_V*(Tpv_hora-Tpv_NOCT));
Vmp_2016(i) = Vmp_hora;

if Vmp_hora > MAX_Vmp
    MAX_Vmp = Vmp_hora;
end    
if Vmp_hora < MIN_Vmp
    MIN_Vmp = Vmp_hora;
end

Imp_hora = Pmax_hora/Vmp_hora;
Imp_2016(i) = Imp_hora;

if Imp_hora > MAX_Imp && G_global_hora>0 
    MAX_Imp = Imp_hora;
end    
if Imp_hora < MIN_Imp && G_global_hora>0 
    MIN_Imp = Imp_hora;
end

%ver dia seguinte 
chr_aux = cell2mat(convertStringsToChars(data_2016.time(i+1)));
chr_dia_seguinte = chr_aux(7:8);
dia_seguinte = str2num(['uint8(',chr_dia_seguinte,')']);

if dia==dia_seguinte
    Cum_Pmax = Cum_Pmax + Pmax_hora;
    if(Pmax_hora>0)
    counter_horas_prod_dia = counter_horas_prod_dia+1;
    end
else
    Cum_Pmax = Cum_Pmax + Pmax_hora;
    if Cum_Pmax > MAX_Pmax_2
        MAX_Pmax_2 = Cum_Pmax;
        best_fevereiro = dia;
    end    
    if Cum_Pmax < MIN_Pmax_2
        MIN_Pmax_2 = Cum_Pmax;
        worst_fevereiro = dia;
    end
    if(Pmax_hora>0)
    counter_horas_prod_dia = counter_horas_prod_dia+1;
    end
    H_prod_diaria(k) = counter_horas_prod_dia;
    P_prod_diaria(k) = Cum_Pmax;
    k = k+1;
    Cum_Pmax=0; 
    counter_horas_prod_dia=0;
end   
end
    
  
    
 


if n==3
%---------------
%MAR�O
%---------------
    
%ver dia atual
chr_dia = chr(7:8);
dia = str2num(['uint8(',chr_dia,')']);

    
G_global_hora = data_2016.G_i_(i);
if G_global_hora>MAX_G_3
    MAX_G_3 = G_global_hora;
elseif G_global_hora<MIN_G_3 && G_global_hora>0
    MIN_G_3 = G_global_hora;
end

Tamb_hora = data_2016.T2m(i);
if Tamb_hora>MAX_Tamb_3
    MAX_Tamb_3 = Tamb_hora;
elseif Tamb_hora<MIN_Tamb_3 && G_global_hora>0 
    MIN_Tamb_3 = Tamb_hora;
end

Tpv_hora = Tamb_hora + (G_global_hora/G_NOCT)*(Tpv_NOCT-Tamb_NOCT); %Tpv é a temp.  do PV panel em agosto/dia
Tpv_2016(i) = Tpv_hora;
if Tpv_hora>MAX_Tpv_3
    MAX_Tpv_3 = Tpv_hora;
elseif Tpv_hora<MIN_Tpv_3 && G_global_hora>0
    MIN_Tpv_3 = Tpv_hora;
end

Pmax_hora = Pmax_NOCT*(G_global_hora/G_NOCT).*(1-temp_coef_Pmax*(Tpv_hora-Tpv_NOCT));
Pmax_2016(i) = Pmax_hora;

Vmp_hora = Vmp_NOCT.*(1-temp_coef_V*(Tpv_hora-Tpv_NOCT));
Vmp_2016(i) = Vmp_hora;

if Vmp_hora > MAX_Vmp
    MAX_Vmp = Vmp_hora;
end    
if Vmp_hora < MIN_Vmp
    MIN_Vmp = Vmp_hora;
end

Imp_hora = Pmax_hora/Vmp_hora;
Imp_2016(i) = Imp_hora;

if Imp_hora > MAX_Imp && G_global_hora>0 
    MAX_Imp = Imp_hora;
end    
if Imp_hora < MIN_Imp && G_global_hora>0 
    MIN_Imp = Imp_hora;
end

%ver dia seguinte 
chr_aux = cell2mat(convertStringsToChars(data_2016.time(i+1)));
chr_dia_seguinte = chr_aux(7:8);
dia_seguinte = str2num(['uint8(',chr_dia_seguinte,')']);

if dia==dia_seguinte
    Cum_Pmax = Cum_Pmax + Pmax_hora;
    if(Pmax_hora>0)
    counter_horas_prod_dia = counter_horas_prod_dia+1;
    end
else
    Cum_Pmax = Cum_Pmax + Pmax_hora;
    if Cum_Pmax > MAX_Pmax_3
        MAX_Pmax_3 = Cum_Pmax;
        best_marco = dia;
    end    
    if Cum_Pmax < MIN_Pmax_3
        MIN_Pmax_3 = Cum_Pmax;
        worst_marco = dia;
    end
    if(Pmax_hora>0)
    counter_horas_prod_dia = counter_horas_prod_dia+1;
    end
    H_prod_diaria(k) = counter_horas_prod_dia;
    P_prod_diaria(k) = Cum_Pmax;
    k = k+1;
    Cum_Pmax=0; 
    counter_horas_prod_dia=0;
end   
end  




if n==4
%---------------
%ABRIL
%---------------

%ver dia atual
chr_dia = chr(7:8);
dia = str2num(['uint8(',chr_dia,')']);

    
G_global_hora = data_2016.G_i_(i);
if G_global_hora>MAX_G_4
    MAX_G_4 = G_global_hora;
elseif G_global_hora<MIN_G_4 && G_global_hora>0
    MIN_G_4 = G_global_hora;
end

Tamb_hora = data_2016.T2m(i);
if Tamb_hora>MAX_Tamb_4
    MAX_Tamb_4 = Tamb_hora;
elseif Tamb_hora<MIN_Tamb_4 && G_global_hora>0 
    MIN_Tamb_4 = Tamb_hora;
end

Tpv_hora = Tamb_hora + (G_global_hora/G_NOCT)*(Tpv_NOCT-Tamb_NOCT); %Tpv é a temp.  do PV panel em agosto/dia
Tpv_2016(i) = Tpv_hora;
if Tpv_hora>MAX_Tpv_4
    MAX_Tpv_4 = Tpv_hora;
elseif Tpv_hora<MIN_Tpv_4 && G_global_hora>0
    MIN_Tpv_4 = Tpv_hora;
end

Pmax_hora = Pmax_NOCT*(G_global_hora/G_NOCT).*(1-temp_coef_Pmax*(Tpv_hora-Tpv_NOCT));
Pmax_2016(i) = Pmax_hora;

Vmp_hora = Vmp_NOCT.*(1-temp_coef_V*(Tpv_hora-Tpv_NOCT));
Vmp_2016(i) = Vmp_hora;

if Vmp_hora > MAX_Vmp
    MAX_Vmp = Vmp_hora;
end    
if Vmp_hora < MIN_Vmp
    MIN_Vmp = Vmp_hora;
end

Imp_hora = Pmax_hora/Vmp_hora;
Imp_2016(i) = Imp_hora;

if Imp_hora > MAX_Imp && G_global_hora>0 
    MAX_Imp = Imp_hora;
end    
if Imp_hora < MIN_Imp && G_global_hora>0 
    MIN_Imp = Imp_hora;
end

%ver dia seguinte 
chr_aux = cell2mat(convertStringsToChars(data_2016.time(i+1)));
chr_dia_seguinte = chr_aux(7:8);
dia_seguinte = str2num(['uint8(',chr_dia_seguinte,')']);

if dia==dia_seguinte
    Cum_Pmax = Cum_Pmax + Pmax_hora;
    if(Pmax_hora>0)
    counter_horas_prod_dia = counter_horas_prod_dia+1;
    end
else
    Cum_Pmax = Cum_Pmax + Pmax_hora;
    if Cum_Pmax > MAX_Pmax_4
        MAX_Pmax_4 = Cum_Pmax;
        best_abril = dia;
    end    
    if Cum_Pmax < MIN_Pmax_4
        MIN_Pmax_4 = Cum_Pmax;
        worst_abril = dia;
    end
    if(Pmax_hora>0)
    counter_horas_prod_dia = counter_horas_prod_dia+1;
    end
    H_prod_diaria(k) = counter_horas_prod_dia;
    P_prod_diaria(k) = Cum_Pmax;
    k = k+1;
    Cum_Pmax=0; 
    counter_horas_prod_dia=0;
end   
end  



if n==5
%---------------
%MAIO
%---------------
%ver dia atual
chr_dia = chr(7:8);
dia = str2num(['uint8(',chr_dia,')']);

    
G_global_hora = data_2016.G_i_(i);
if G_global_hora>MAX_G_5
    MAX_G_5 = G_global_hora;
elseif G_global_hora<MIN_G_5 && G_global_hora>0
    MIN_G_5 = G_global_hora;
end

Tamb_hora = data_2016.T2m(i);
if Tamb_hora>MAX_Tamb_5
    MAX_Tamb_5 = Tamb_hora;
elseif Tamb_hora<MIN_Tamb_5 && G_global_hora>0 
    MIN_Tamb_5 = Tamb_hora;
end

Tpv_hora = Tamb_hora + (G_global_hora/G_NOCT)*(Tpv_NOCT-Tamb_NOCT); %Tpv é a temp.  do PV panel em agosto/dia
Tpv_2016(i) = Tpv_hora;
if Tpv_hora>MAX_Tpv_5
    MAX_Tpv_5 = Tpv_hora;
elseif Tpv_hora<MIN_Tpv_5 && G_global_hora>0
    MIN_Tpv_5 = Tpv_hora;
end

Pmax_hora = Pmax_NOCT*(G_global_hora/G_NOCT).*(1-temp_coef_Pmax*(Tpv_hora-Tpv_NOCT));
Pmax_2016(i) = Pmax_hora;

Vmp_hora = Vmp_NOCT.*(1-temp_coef_V*(Tpv_hora-Tpv_NOCT));
Vmp_2016(i) = Vmp_hora;

if Vmp_hora > MAX_Vmp
    MAX_Vmp = Vmp_hora;
end    
if Vmp_hora < MIN_Vmp
    MIN_Vmp = Vmp_hora;
end

Imp_hora = Pmax_hora/Vmp_hora;
Imp_2016(i) = Imp_hora;

if Imp_hora > MAX_Imp && G_global_hora>0 
    MAX_Imp = Imp_hora;
end    
if Imp_hora < MIN_Imp && G_global_hora>0 
    MIN_Imp = Imp_hora;
end

%ver dia seguinte 
chr_aux = cell2mat(convertStringsToChars(data_2016.time(i+1)));
chr_dia_seguinte = chr_aux(7:8);
dia_seguinte = str2num(['uint8(',chr_dia_seguinte,')']);

if dia==dia_seguinte
    Cum_Pmax = Cum_Pmax + Pmax_hora;
    if(Pmax_hora>0)
    counter_horas_prod_dia = counter_horas_prod_dia+1;
    end
else
    Cum_Pmax = Cum_Pmax + Pmax_hora;
    if Cum_Pmax > MAX_Pmax_5
        MAX_Pmax_5 = Cum_Pmax;
        best_maio = dia;
    end    
    if Cum_Pmax < MIN_Pmax_5
        MIN_Pmax_5 = Cum_Pmax;
        worst_maio = dia;
    end
    if(Pmax_hora>0)
    counter_horas_prod_dia = counter_horas_prod_dia+1;
    end
    H_prod_diaria(k) = counter_horas_prod_dia;
    P_prod_diaria(k) = Cum_Pmax;
    k = k+1;
    Cum_Pmax=0; 
    counter_horas_prod_dia=0;
end   
end






if n==6
%---------------
%JUNHO
%---------------
%ver dia atual
chr_dia = chr(7:8);
dia = str2num(['uint8(',chr_dia,')']);

    
G_global_hora = data_2016.G_i_(i);
if G_global_hora>MAX_G_6
    MAX_G_6 = G_global_hora;
elseif G_global_hora<MIN_G_6 && G_global_hora>0
    MIN_G_6 = G_global_hora;
end

Tamb_hora = data_2016.T2m(i);
if Tamb_hora>MAX_Tamb_6
    MAX_Tamb_6 = Tamb_hora;
elseif Tamb_hora<MIN_Tamb_6 && G_global_hora>0 
    MIN_Tamb_6 = Tamb_hora;
end

Tpv_hora = Tamb_hora + (G_global_hora/G_NOCT)*(Tpv_NOCT-Tamb_NOCT); %Tpv é a temp.  do PV panel em agosto/dia
Tpv_2016(i) = Tpv_hora;
if Tpv_hora>MAX_Tpv_6
    MAX_Tpv_6 = Tpv_hora;
elseif Tpv_hora<MIN_Tpv_6 && G_global_hora>0
    MIN_Tpv_6 = Tpv_hora;
end

Pmax_hora = Pmax_NOCT*(G_global_hora/G_NOCT).*(1-temp_coef_Pmax*(Tpv_hora-Tpv_NOCT));
Pmax_2016(i) = Pmax_hora;

Vmp_hora = Vmp_NOCT.*(1-temp_coef_V*(Tpv_hora-Tpv_NOCT));
Vmp_2016(i) = Vmp_hora;

if Vmp_hora > MAX_Vmp
    MAX_Vmp = Vmp_hora;
end    
if Vmp_hora < MIN_Vmp
    MIN_Vmp = Vmp_hora;
end

Imp_hora = Pmax_hora/Vmp_hora;
Imp_2016(i) = Imp_hora;

if Imp_hora > MAX_Imp && G_global_hora>0 
    MAX_Imp = Imp_hora;
end    
if Imp_hora < MIN_Imp && G_global_hora>0 
    MIN_Imp = Imp_hora;
end

%ver dia seguinte 
chr_aux = cell2mat(convertStringsToChars(data_2016.time(i+1)));
chr_dia_seguinte = chr_aux(7:8);
dia_seguinte = str2num(['uint8(',chr_dia_seguinte,')']);

if dia==dia_seguinte
    Cum_Pmax = Cum_Pmax + Pmax_hora;
    if(Pmax_hora>0)
    counter_horas_prod_dia = counter_horas_prod_dia+1;
    end
else
    Cum_Pmax = Cum_Pmax + Pmax_hora;
    if Cum_Pmax > MAX_Pmax_6
        MAX_Pmax_6 = Cum_Pmax;
        best_junho = dia;
    end    
    if Cum_Pmax < MIN_Pmax_6
        MIN_Pmax_6 = Cum_Pmax;
        worst_junho = dia;
    end
    if(Pmax_hora>0)
    counter_horas_prod_dia = counter_horas_prod_dia+1;
    end
    H_prod_diaria(k) = counter_horas_prod_dia;
    P_prod_diaria(k) = Cum_Pmax;
    k = k+1;
    Cum_Pmax=0; 
    counter_horas_prod_dia=0;
end   
end





if n==7
%---------------
%JULHO
%---------------
%ver dia atual
chr_dia = chr(7:8);
dia = str2num(['uint8(',chr_dia,')']);

    
G_global_hora = data_2016.G_i_(i);
if G_global_hora>MAX_G_7
    MAX_G_7 = G_global_hora;
elseif G_global_hora<MIN_G_7 && G_global_hora>0
    MIN_G_7 = G_global_hora;
end

Tamb_hora = data_2016.T2m(i);
if Tamb_hora>MAX_Tamb_7
    MAX_Tamb_7 = Tamb_hora;
elseif Tamb_hora<MIN_Tamb_7 && G_global_hora>0 
    MIN_Tamb_7 = Tamb_hora;
end

Tpv_hora = Tamb_hora + (G_global_hora/G_NOCT)*(Tpv_NOCT-Tamb_NOCT); %Tpv é a temp.  do PV panel em agosto/dia
Tpv_2016(i) = Tpv_hora;
if Tpv_hora>MAX_Tpv_7
    MAX_Tpv_7 = Tpv_hora;
elseif Tpv_hora<MIN_Tpv_7 && G_global_hora>0
    MIN_Tpv_7 = Tpv_hora;
end

Pmax_hora = Pmax_NOCT*(G_global_hora/G_NOCT).*(1-temp_coef_Pmax*(Tpv_hora-Tpv_NOCT));
Pmax_2016(i) = Pmax_hora;

Vmp_hora = Vmp_NOCT.*(1-temp_coef_V*(Tpv_hora-Tpv_NOCT));
Vmp_2016(i) = Vmp_hora;

if Vmp_hora > MAX_Vmp
    MAX_Vmp = Vmp_hora;
end    
if Vmp_hora < MIN_Vmp
    MIN_Vmp = Vmp_hora;
end

Imp_hora = Pmax_hora/Vmp_hora;
Imp_2016(i) = Imp_hora;

if Imp_hora > MAX_Imp && G_global_hora>0 
    MAX_Imp = Imp_hora;
end    
if Imp_hora < MIN_Imp && G_global_hora>0 
    MIN_Imp = Imp_hora;
end

%ver dia seguinte 
chr_aux = cell2mat(convertStringsToChars(data_2016.time(i+1)));
chr_dia_seguinte = chr_aux(7:8);
dia_seguinte = str2num(['uint8(',chr_dia_seguinte,')']);

if dia==dia_seguinte
    Cum_Pmax = Cum_Pmax + Pmax_hora;
    if(Pmax_hora>0)
    counter_horas_prod_dia = counter_horas_prod_dia+1;
    end
else
    Cum_Pmax = Cum_Pmax + Pmax_hora;
    if Cum_Pmax > MAX_Pmax_7
        MAX_Pmax_7 = Cum_Pmax;
        best_julho = dia;
    end    
    if Cum_Pmax < MIN_Pmax_7
        MIN_Pmax_7 = Cum_Pmax;
        worst_julho = dia;
    end
    if(Pmax_hora>0)
    counter_horas_prod_dia = counter_horas_prod_dia+1;
    end
    H_prod_diaria(k) = counter_horas_prod_dia;
    P_prod_diaria(k) = Cum_Pmax;
    k = k+1;
    Cum_Pmax=0; 
    counter_horas_prod_dia=0;
end   
end    





if n==8
%---------------
%AGOSTO
%---------------
%ver dia atual
chr_dia = chr(7:8);
dia = str2num(['uint8(',chr_dia,')']);

    
G_global_hora = data_2016.G_i_(i);
if G_global_hora>MAX_G_8
    MAX_G_8 = G_global_hora;
elseif G_global_hora<MIN_G_8 && G_global_hora>0
    MIN_G_8 = G_global_hora;
end

Tamb_hora = data_2016.T2m(i);
if Tamb_hora>MAX_Tamb_8
    MAX_Tamb_8 = Tamb_hora;
elseif Tamb_hora<MIN_Tamb_8 && G_global_hora>0 
    MIN_Tamb_8 = Tamb_hora;
end

Tpv_hora = Tamb_hora + (G_global_hora/G_NOCT)*(Tpv_NOCT-Tamb_NOCT); %Tpv é a temp.  do PV panel em agosto/dia
Tpv_2016(i) = Tpv_hora;
if Tpv_hora>MAX_Tpv_8
    MAX_Tpv_8 = Tpv_hora;
elseif Tpv_hora<MIN_Tpv_8 && G_global_hora>0
    MIN_Tpv_8 = Tpv_hora;
end

Pmax_hora = Pmax_NOCT*(G_global_hora/G_NOCT).*(1-temp_coef_Pmax*(Tpv_hora-Tpv_NOCT));
Pmax_2016(i) = Pmax_hora;

Vmp_hora = Vmp_NOCT.*(1-temp_coef_V*(Tpv_hora-Tpv_NOCT));
Vmp_2016(i) = Vmp_hora;

if Vmp_hora > MAX_Vmp
    MAX_Vmp = Vmp_hora;
end    
if Vmp_hora < MIN_Vmp
    MIN_Vmp = Vmp_hora;
end

Imp_hora = Pmax_hora/Vmp_hora;
Imp_2016(i) = Imp_hora;

if Imp_hora > MAX_Imp && G_global_hora>0 
    MAX_Imp = Imp_hora;
end    
if Imp_hora < MIN_Imp && G_global_hora>0 
    MIN_Imp = Imp_hora;
end

%ver dia seguinte 
chr_aux = cell2mat(convertStringsToChars(data_2016.time(i+1)));
chr_dia_seguinte = chr_aux(7:8);
dia_seguinte = str2num(['uint8(',chr_dia_seguinte,')']);

if dia==dia_seguinte
    Cum_Pmax = Cum_Pmax + Pmax_hora;
    if(Pmax_hora>0)
    counter_horas_prod_dia = counter_horas_prod_dia+1;
    end
else
    Cum_Pmax = Cum_Pmax + Pmax_hora;
    if Cum_Pmax > MAX_Pmax_8
        MAX_Pmax_8 = Cum_Pmax;
        best_agosto = dia;
    end    
    if Cum_Pmax < MIN_Pmax_8
        MIN_Pmax_8 = Cum_Pmax;
        worst_agosto = dia;
        
    end
    if(Pmax_hora>0)
    counter_horas_prod_dia = counter_horas_prod_dia+1;
    end
    H_prod_diaria(k) = counter_horas_prod_dia;
    P_prod_diaria(k) = Cum_Pmax;
    k = k+1;
    Cum_Pmax=0; 
    counter_horas_prod_dia=0;
end   
end   





if n==9
%---------------
%SETEMBRO
%---------------
%ver dia atual
chr_dia = chr(7:8);
dia = str2num(['uint8(',chr_dia,')']);

    
G_global_hora = data_2016.G_i_(i);
if G_global_hora>MAX_G_9
    MAX_G_9 = G_global_hora;
elseif G_global_hora<MIN_G_9 && G_global_hora>0
    MIN_G_9 = G_global_hora;
end

Tamb_hora = data_2016.T2m(i);
if Tamb_hora>MAX_Tamb_9
    MAX_Tamb_9 = Tamb_hora;
elseif Tamb_hora<MIN_Tamb_9 && G_global_hora>0 
    MIN_Tamb_9 = Tamb_hora;
end

Tpv_hora = Tamb_hora + (G_global_hora/G_NOCT)*(Tpv_NOCT-Tamb_NOCT); %Tpv é a temp.  do PV panel em agosto/dia
Tpv_2016(i) = Tpv_hora;
if Tpv_hora>MAX_Tpv_9
    MAX_Tpv_9 = Tpv_hora;
elseif Tpv_hora<MIN_Tpv_9 && G_global_hora>0
    MIN_Tpv_9 = Tpv_hora;
end

Pmax_hora = Pmax_NOCT*(G_global_hora/G_NOCT).*(1-temp_coef_Pmax*(Tpv_hora-Tpv_NOCT));
Pmax_2016(i) = Pmax_hora;

Vmp_hora = Vmp_NOCT.*(1-temp_coef_V*(Tpv_hora-Tpv_NOCT));
Vmp_2016(i) = Vmp_hora;

if Vmp_hora > MAX_Vmp
    MAX_Vmp = Vmp_hora;
end    
if Vmp_hora < MIN_Vmp
    MIN_Vmp = Vmp_hora;
end

Imp_hora = Pmax_hora/Vmp_hora;
Imp_2016(i) = Imp_hora;

if Imp_hora > MAX_Imp && G_global_hora>0 
    MAX_Imp = Imp_hora;
end    
if Imp_hora < MIN_Imp && G_global_hora>0 
    MIN_Imp = Imp_hora;
end

%ver dia seguinte 
chr_aux = cell2mat(convertStringsToChars(data_2016.time(i+1)));
chr_dia_seguinte = chr_aux(7:8);
dia_seguinte = str2num(['uint8(',chr_dia_seguinte,')']);

if dia==dia_seguinte
    Cum_Pmax = Cum_Pmax + Pmax_hora;
    if(Pmax_hora>0)
    counter_horas_prod_dia = counter_horas_prod_dia+1;
    end
else
    Cum_Pmax = Cum_Pmax + Pmax_hora;
    if Cum_Pmax > MAX_Pmax_9
        MAX_Pmax_9 = Cum_Pmax;
        best_setembro = dia;    
    end    
    if Cum_Pmax < MIN_Pmax_9
        MIN_Pmax_9 = Cum_Pmax;
        worst_setembro = dia;
    end
    if(Pmax_hora>0)
    counter_horas_prod_dia = counter_horas_prod_dia+1;
    end
    H_prod_diaria(k) = counter_horas_prod_dia;
    P_prod_diaria(k) = Cum_Pmax;
    k = k+1;
    Cum_Pmax=0; 
    counter_horas_prod_dia=0;
end   
end  







if n==10
%---------------
%OUTUBRO
%---------------
%ver dia atual
chr_dia = chr(7:8);
dia = str2num(['uint8(',chr_dia,')']);

    
G_global_hora = data_2016.G_i_(i);
if G_global_hora>MAX_G_10
    MAX_G_10 = G_global_hora;
elseif G_global_hora<MIN_G_10 && G_global_hora>0
    MIN_G_10 = G_global_hora;
end

Tamb_hora = data_2016.T2m(i);
if Tamb_hora>MAX_Tamb_10
    MAX_Tamb_10 = Tamb_hora;
elseif Tamb_hora<MIN_Tamb_10  && G_global_hora>0 
    MIN_Tamb_10 = Tamb_hora;
end

Tpv_hora = Tamb_hora + (G_global_hora/G_NOCT)*(Tpv_NOCT-Tamb_NOCT); %Tpv é a temp.  do PV panel em agosto/dia
Tpv_2016(i) = Tpv_hora;
if Tpv_hora>MAX_Tpv_10
    MAX_Tpv_10 = Tpv_hora;
elseif Tpv_hora<MIN_Tpv_10 && G_global_hora>0
    MIN_Tpv_10 = Tpv_hora;
end

Pmax_hora = Pmax_NOCT*(G_global_hora/G_NOCT).*(1-temp_coef_Pmax*(Tpv_hora-Tpv_NOCT));
Pmax_2016(i) = Pmax_hora;

Vmp_hora = Vmp_NOCT.*(1-temp_coef_V*(Tpv_hora-Tpv_NOCT));
Vmp_2016(i) = Vmp_hora;

if Vmp_hora > MAX_Vmp
    MAX_Vmp = Vmp_hora;
end    
if Vmp_hora < MIN_Vmp
    MIN_Vmp = Vmp_hora;
end

Imp_hora = Pmax_hora/Vmp_hora;
Imp_2016(i) = Imp_hora;

if Imp_hora > MAX_Imp && G_global_hora>0 
    MAX_Imp = Imp_hora;
end    
if Imp_hora < MIN_Imp && G_global_hora>0 
    MIN_Imp = Imp_hora;
end

%ver dia seguinte 
chr_aux = cell2mat(convertStringsToChars(data_2016.time(i+1)));
chr_dia_seguinte = chr_aux(7:8);
dia_seguinte = str2num(['uint8(',chr_dia_seguinte,')']);

if dia==dia_seguinte
    Cum_Pmax = Cum_Pmax + Pmax_hora;
    if(Pmax_hora>0)
    counter_horas_prod_dia = counter_horas_prod_dia+1;
    end
else
    Cum_Pmax = Cum_Pmax + Pmax_hora;
    if Cum_Pmax > MAX_Pmax_10
        MAX_Pmax_10 = Cum_Pmax;
        best_outubro = dia;
    end    
    if Cum_Pmax < MIN_Pmax_10
        MIN_Pmax_10 = Cum_Pmax;
        worst_outubro = dia;
    end
    if(Pmax_hora>0)
    counter_horas_prod_dia = counter_horas_prod_dia+1;
    end
    H_prod_diaria(k) = counter_horas_prod_dia;
    P_prod_diaria(k) = Cum_Pmax;
    k = k+1;
    Cum_Pmax=0; 
    counter_horas_prod_dia=0;
end   
end







if n==11
%---------------
%NOVEMBRO
%---------------
%ver dia atual
chr_dia = chr(7:8);
dia = str2num(['uint8(',chr_dia,')']);

    
G_global_hora = data_2016.G_i_(i);
if G_global_hora>MAX_G_11
    MAX_G_11 = G_global_hora;
elseif G_global_hora<MIN_G_11 && G_global_hora>0
    MIN_G_11 = G_global_hora;
end

Tamb_hora = data_2016.T2m(i);
if Tamb_hora>MAX_Tamb_11
    MAX_Tamb_11 = Tamb_hora;
elseif Tamb_hora<MIN_Tamb_11 && G_global_hora>0 
    MIN_Tamb_11 = Tamb_hora;
end

Tpv_hora = Tamb_hora + (G_global_hora/G_NOCT)*(Tpv_NOCT-Tamb_NOCT); %Tpv é a temp.  do PV panel em agosto/dia
Tpv_2016(i) = Tpv_hora;
if Tpv_hora>MAX_Tpv_11
    MAX_Tpv_11 = Tpv_hora;
elseif Tpv_hora<MIN_Tpv_11 && G_global_hora>0
    MIN_Tpv_11 = Tpv_hora;
end

Pmax_hora = Pmax_NOCT*(G_global_hora/G_NOCT).*(1-temp_coef_Pmax*(Tpv_hora-Tpv_NOCT));
Pmax_2016(i) = Pmax_hora;

Vmp_hora = Vmp_NOCT.*(1-temp_coef_V*(Tpv_hora-Tpv_NOCT));
Vmp_2016(i) = Vmp_hora;

if Vmp_hora > MAX_Vmp
    MAX_Vmp = Vmp_hora;
end    
if Vmp_hora < MIN_Vmp
    MIN_Vmp = Vmp_hora;
end

Imp_hora = Pmax_hora/Vmp_hora;
Imp_2016(i) = Imp_hora;

if Imp_hora > MAX_Imp && G_global_hora>0 
    MAX_Imp = Imp_hora;
end    
if Imp_hora < MIN_Imp && G_global_hora>0 
    MIN_Imp = Imp_hora;
end

%ver dia seguinte 
chr_aux = cell2mat(convertStringsToChars(data_2016.time(i+1)));
chr_dia_seguinte = chr_aux(7:8);
dia_seguinte = str2num(['uint8(',chr_dia_seguinte,')']);

if dia==dia_seguinte
    Cum_Pmax = Cum_Pmax + Pmax_hora;
    if(Pmax_hora>0)
    counter_horas_prod_dia = counter_horas_prod_dia+1;
    end
else
    Cum_Pmax = Cum_Pmax + Pmax_hora;
    if Cum_Pmax > MAX_Pmax_11
        MAX_Pmax_11 = Cum_Pmax;
        best_novembro = dia;
    end    
    if Cum_Pmax < MIN_Pmax_11
        MIN_Pmax_11 = Cum_Pmax;
        worst_novembro = dia;
    end
    if(Pmax_hora>0)
    counter_horas_prod_dia = counter_horas_prod_dia+1;
    end
    H_prod_diaria(k) = counter_horas_prod_dia;
    P_prod_diaria(k) = Cum_Pmax;
    k = k+1;
    Cum_Pmax=0; 
    counter_horas_prod_dia=0;
end   
end 






if n==12
%---------------
%DEZEMBRO
%---------------
%ver dia atual
chr_dia = chr(7:8);
dia = str2num(['uint8(',chr_dia,')']);

    
G_global_hora = data_2016.G_i_(i);
if G_global_hora>MAX_G_12
    MAX_G_12 = G_global_hora;
elseif G_global_hora<MIN_G_12 && G_global_hora>0
    MIN_G_12 = G_global_hora;
end

Tamb_hora = data_2016.T2m(i);
if Tamb_hora>MAX_Tamb_12
    MAX_Tamb_12 = Tamb_hora;
elseif Tamb_hora<MIN_Tamb_12 && G_global_hora>0 
    MIN_Tamb_12 = Tamb_hora;
end

Tpv_hora = Tamb_hora + (G_global_hora/G_NOCT)*(Tpv_NOCT-Tamb_NOCT); %Tpv é a temp.  do PV panel em agosto/dia
Tpv_2016(i) = Tpv_hora;
if Tpv_hora>MAX_Tpv_12
    MAX_Tpv_12 = Tpv_hora;
elseif Tpv_hora<MIN_Tpv_12 && G_global_hora>0
    MIN_Tpv_12 = Tpv_hora;
end

Pmax_hora = Pmax_NOCT*(G_global_hora/G_NOCT).*(1-temp_coef_Pmax*(Tpv_hora-Tpv_NOCT));
Pmax_2016(i) = Pmax_hora;

Vmp_hora = Vmp_NOCT.*(1-temp_coef_V*(Tpv_hora-Tpv_NOCT));
Vmp_2016(i) = Vmp_hora;

if Vmp_hora > MAX_Vmp
    MAX_Vmp = Vmp_hora;
end    
if Vmp_hora < MIN_Vmp
    MIN_Vmp = Vmp_hora;
end

Imp_hora = Pmax_hora/Vmp_hora;
Imp_2016(i) = Imp_hora;

if Imp_hora > MAX_Imp && G_global_hora>0 
    MAX_Imp = Imp_hora;
end    
if Imp_hora < MIN_Imp && G_global_hora>0 
    MIN_Imp = Imp_hora;
end

%ver dia seguinte
if i==8783
   Cum_Pmax = Cum_Pmax + Pmax_hora;
    if Cum_Pmax > MAX_Pmax_12
        MAX_Pmax_12 = Cum_Pmax;
        best_dezembro = dia;
    end    
    if Cum_Pmax < MIN_Pmax_12
        MIN_Pmax_12 = Cum_Pmax;
        worst_dezembro = dia;
    end
    if(Pmax_hora>0)
    counter_horas_prod_dia = counter_horas_prod_dia+1;
    end
    H_prod_diaria(k) = counter_horas_prod_dia;
    P_prod_diaria(k) = Cum_Pmax;
    
else    
chr_aux = cell2mat(convertStringsToChars(data_2016.time(i+1)));
chr_dia_seguinte = chr_aux(7:8);
dia_seguinte = str2num(['uint8(',chr_dia_seguinte,')']);

if dia==dia_seguinte
    Cum_Pmax = Cum_Pmax + Pmax_hora;
    if(Pmax_hora>0)
    counter_horas_prod_dia = counter_horas_prod_dia+1;
    end
else
    Cum_Pmax = Cum_Pmax + Pmax_hora;
    if Cum_Pmax > MAX_Pmax_12
        MAX_Pmax_12 = Cum_Pmax;
        best_dezembro = dia;
    end    
    if Cum_Pmax < MIN_Pmax_12
        MIN_Pmax_12 = Cum_Pmax;
        worst_dezembro = dia;
    end
    if(Pmax_hora>0)
    counter_horas_prod_dia = counter_horas_prod_dia+1;
    end
    H_prod_diaria(k) = counter_horas_prod_dia;
    P_prod_diaria(k) = Cum_Pmax;
    k = k+1;
    Cum_Pmax=0; 
    counter_horas_prod_dia=0;
end   
end  
end

end


%Acerto do numero de horas de produ��o di�rias
H_prod_diaria = H_prod_diaria-1;



%% PLOTS dos dados antes da analise de custo
figure(1)
plot(data_2016.G_i_)
xlabel('horas do ano')
ylabel('G [W/m^2]')
title('Global solar irradiance hourly data for 2016')

figure(2)
plot(data_2016.T2m)
xlabel('horas do ano')
ylabel('Tamb [C�]')
title('Ambient Temp. hourly data for 2016')

figure(3)
plot(Pmax_2016)
xlabel('horas do ano')
ylabel('Pmax [W]')
title('Pmax Output hourly data for 2016|LG')


figure(4)
plot(Tpv_2016)
xlabel('horas do ano')
ylabel('Tpv [C�]')
title('PV Temp. hourly data for 2016|LG')

figure(5)
plot(Vmp_2016)
xlabel('horas do ano')
ylabel('Vmp [V]')
title('Vmp hourly data for 2016|LG')

figure(6)
plot(Imp_2016)
xlabel('horas do ano')
ylabel('Imp [A]')
title('Imp hourly data for 2016|LG')

figure(7)
y = [MAX_G_1  MAX_G_2 MAX_G_3 MAX_G_4 MAX_G_5 MAX_G_6 MAX_G_7 MAX_G_8 MAX_G_9 MAX_G_10 MAX_G_11 MAX_G_12];
b = bar(y);
xlabel('Meses do ano')
ylabel('G [W]')
title('Valor m�x.numa dada hora de Global Irradiance/m�s')


figure(8)
y = [MIN_G_1  MIN_G_2 MIN_G_3 MIN_G_4 MIN_G_5 MIN_G_6 MIN_G_7 MIN_G_8 MIN_G_9 MIN_G_10 MIN_G_11 MIN_G_12];
b = bar(y);
xlabel('Meses do ano')
ylabel('G [W]')
title('Valor min.numa dada hora de Global Irradiance/m�s')

figure(9)
y = [MAX_Tamb_1  MIN_Tamb_1;MAX_Tamb_2 MIN_Tamb_2;MAX_Tamb_3 MIN_Tamb_3;MAX_Tamb_4 MIN_Tamb_4;MAX_Tamb_5 MIN_Tamb_5;MAX_Tamb_6 MIN_Tamb_6;MAX_Tamb_7 MIN_Tamb_7;MAX_Tamb_8 MIN_Tamb_8;MAX_Tamb_9 MIN_Tamb_9;MAX_Tamb_10 MIN_Tamb_10;MAX_Tamb_11 MIN_Tamb_11;MAX_Tamb_12 MIN_Tamb_12];
b = bar(y);
xlabel('Meses do ano')
ylabel('Temp [�C]')
title('Temp. Ambiente min e m�x numa dada hora/m�s')
legend('M�x','Min')


figure(10)
y = [37.0196  38.095;46.8569 48.1721;51.1977 52.6046;57.5432 58.8612;58.1902 59.5306;63.5523 64.8015;63.5355 64.8153;64.1511 65.4262;59.6395 60.9828;56.9882 58.2481;47.0594 48.229375;36.3335 37.4515];
b = bar(y);
xlabel('Meses do ano')
ylabel('Temp [�C]')
title('Temp. M�x Pv Panel numa dada hora/m�s')
legend('LG','SHARP')


figure(11)
y = [-10.3177  -10.2821875;1.8283 1.8528125;3.6929 3.7634375;4.6322 4.644375;14.1171 14.1940625;17.3546 17.373125;20.305 20.366875;22.3861 22.4259375;14.2952 14.39625;4.0319 4.0753125;3.1825 3.2221875;-5.8038 -5.795625];
b = bar(y);
xlabel('Meses do ano')
ylabel('Temp [�C]')
title('Temp. Min Pv Panel numa dada hora/m�s')
legend('LG','SHARP')

figure(12)
y = [1826.51179578307  1582.88490481888;2451.06338078491 2143.35271797408;2660.66245616622 2318.35239966430;2786.21005188024 2458.61927568720;2903.80126824520 2556.94464032641;2896.06815548056 2563.47844130448;2856.85936593806 2532.56681677127;2819.21481674792 2497.66914162605;2705.74827246614 2390.16695060382;2516.31144561945 2210.54042041160;2056.98776690927 1799.46810011109;1820.02723488822 1566.41793834434];
b = bar(y);
xlabel('Meses do ano')
ylabel('Pmax [W]')
title('MAX. Cumulative Power Output di�ria/m�s')
legend('LG','SHARP')


area_efetiva_LG = 1.62016;
PIN = area_efetiva_LG * data_2016.G_i_;
eff_LG = Pmax_2016./(PIN)';
figure(13)
plot(eff_LG*100)
xlabel('horas do ano')
ylabel('Efici�cnia [%]')
title('Efici�ncia de 1 painel LG,hourly data for 2016')


figure(14)
y = [111.5043932833538  94.2032505926230;159.356071925471 134.324047087768;318.4208866293862 271.012609664713;386.0621163935437 330.431171113818;354.8143459387013 304.916847473807;433.836937588433 371.847807813645;826.3175318917088 714.816584387842;2035.085255741081 1798.64848466312;335.6224705229288 288.846832687561;137.4467294802938 116.704924769467;123.7213352517863 104.064387806299;146.8648483872525 124.181519143910];
b = bar(y);
xlabel('Meses do ano')
ylabel('Pmax [W]')
title('MIN. Cumulative Power Output di�ria/m�s')
legend('LG','SHARP')




%% C�lculo do n�mero de paineis necess�rios para assegurar a load nas horas de produ��o cada m�s para o pior e melhor dia


%vetores do numero de paineis/hora necess�rios para alimentar a load (100
%rigs) nos piores dias de cada m�s
n_p_per_hour_worst_jan = zeros(24,1);
n_p_per_hour_worst_fev = zeros(24,1);
n_p_per_hour_worst_mar = zeros(24,1);
n_p_per_hour_worst_abr = zeros(24,1);
n_p_per_hour_worst_mai = zeros(24,1);
n_p_per_hour_worst_jun = zeros(24,1);
n_p_per_hour_worst_jul = zeros(24,1);
n_p_per_hour_worst_ago = zeros(24,1);
n_p_per_hour_worst_set = zeros(24,1);
n_p_per_hour_worst_out = zeros(24,1);
n_p_per_hour_worst_nov = zeros(24,1);
n_p_per_hour_worst_dez = zeros(24,1);


%vetores do numero de paineis/hora necess�rios para alimentar a load (100
%rigs) nos melhores dias de cada m�s
n_p_per_hour_best_jan = zeros(24,1);
n_p_per_hour_best_fev = zeros(24,1);
n_p_per_hour_best_mar = zeros(24,1);
n_p_per_hour_best_abr = zeros(24,1);
n_p_per_hour_best_mai = zeros(24,1);
n_p_per_hour_best_jun = zeros(24,1);
n_p_per_hour_best_jul = zeros(24,1);
n_p_per_hour_best_ago = zeros(24,1);
n_p_per_hour_best_set = zeros(24,1);
n_p_per_hour_best_out = zeros(24,1);
n_p_per_hour_best_nov = zeros(24,1);
n_p_per_hour_best_dez = zeros(24,1);


%caracteristicas das mining rigs escolhidas:
%A10 Pro ETH Miner 
Load_hora_A10 = 950; %[W]
Load_vents = 135*5;

q=0;

for i=1:8783

chr = cell2mat(convertStringsToChars(data_2016.time(i)));%ver que m�s nos encontramos
chr_mes = chr(5:6);
n = str2num(['uint8(',chr_mes,')']); 

if n==1
%---------------
%JANEIRO
%---------------

%ver dia atual
chr_dia = chr(7:8);
dia = str2num(['uint8(',chr_dia,')']);

%pior dia
if dia == worst_janeiro

    if Pmax_2016(i)>0
    n_p_per_hour_worst_jan(q) = (Load_hora_A10*100+Load_vents)/Pmax_2016(i);
    end
    
    q=q+1;
    if q==24
        q=0;
    end
end


%melhor dia
if dia == best_janeiro

    if Pmax_2016(i)>0
    n_p_per_hour_best_jan(q) = (Load_hora_A10*100+Load_vents)/Pmax_2016(i);
    end
    
    q=q+1;
    if q ==24
        q=0;
    end
end
end





if n==2
%---------------
%FEVEREIRO
%---------------

%ver dia atual
chr_dia = chr(7:8);
dia = str2num(['uint8(',chr_dia,')']);

%pior dia
if dia == worst_fevereiro

    if Pmax_2016(i)>0
    n_p_per_hour_worst_fev(q) = (Load_hora_A10*100+Load_vents)/Pmax_2016(i);
    end
    
    q=q+1;
    if q==24
        q=0;
    end
end


%melhor dia
if dia == best_fevereiro

    if Pmax_2016(i)>0
    n_p_per_hour_best_fev(q) = (Load_hora_A10*100+Load_vents)/Pmax_2016(i);
    end
    
    q=q+1;
    if q ==24
        q=0;
    end
end
end
    
  
    
 


if n==3
%---------------
%MAR�O
%---------------

%ver dia atual
chr_dia = chr(7:8);
dia = str2num(['uint8(',chr_dia,')']);

%pior dia
if dia == worst_marco

    if Pmax_2016(i)>0
    n_p_per_hour_worst_mar(q) = (Load_hora_A10*100+Load_vents)/Pmax_2016(i);
    end
    
    q=q+1;
    if q==24
        q=0;
    end
end


%melhor dia
if dia == best_marco

    if Pmax_2016(i)>0
    n_p_per_hour_best_mar(q) = (Load_hora_A10*100+Load_vents)/Pmax_2016(i);
    end
    
    q=q+1;
    if q ==24
        q=0;
    end
end
end




if n==4
%---------------
%ABRIL
%---------------

%ver dia atual
chr_dia = chr(7:8);
dia = str2num(['uint8(',chr_dia,')']);

%pior dia
if dia == worst_abril

    if Pmax_2016(i)>0
    n_p_per_hour_worst_abr(q) = (Load_hora_A10*100+Load_vents)/Pmax_2016(i);
    end
    
    q=q+1;
    if q==24
        q=0;
    end
end

%melhor dia
if dia == best_abril

    if Pmax_2016(i)>0
    n_p_per_hour_best_abr(q) = (Load_hora_A10*100+Load_vents)/Pmax_2016(i);
    end
    
    q=q+1;
    if q ==24
        q=0;
    end
end
end



if n==5
%---------------
%MAIO
%---------------

%ver dia atual
chr_dia = chr(7:8);
dia = str2num(['uint8(',chr_dia,')']);

%pior dia
if dia == worst_maio

    if Pmax_2016(i)>0
    n_p_per_hour_worst_mai(q) = (Load_hora_A10*100+Load_vents)/Pmax_2016(i);
    end
    
    q=q+1;
    if q==24
        q=0;
    end
end

%melhor dia
if dia == best_maio

    if Pmax_2016(i)>0
    n_p_per_hour_best_mai(q) = (Load_hora_A10*100+Load_vents)/Pmax_2016(i);
    end
    
    q=q+1;
    if q ==24
        q=0;
    end
end
end






if n==6
%---------------
%JUNHO
%---------------

%ver dia atual
chr_dia = chr(7:8);
dia = str2num(['uint8(',chr_dia,')']);

%pior dia
if dia == worst_junho

    if Pmax_2016(i)>0
    n_p_per_hour_worst_jun(q) = (Load_hora_A10*100+Load_vents)/Pmax_2016(i);
    end
    
    q=q+1;
    if q==24
        q=0;
    end
end

%melhor dia
if dia == best_junho

    if Pmax_2016(i)>0
    n_p_per_hour_best_jun(q) = (Load_hora_A10*100)/Pmax_2016(i);
    end
    
    q=q+1;
    if q ==24
        q=0;
    end
end
end





if n==7
%---------------
%JULHO
%---------------

%ver dia atual
chr_dia = chr(7:8);
dia = str2num(['uint8(',chr_dia,')']);

%pior dia
if dia == worst_julho

    if Pmax_2016(i)>0
    n_p_per_hour_worst_jul(q) = (Load_hora_A10*100+Load_vents)/Pmax_2016(i);
    end
    
    q=q+1;
    if q==24
        q=0;
    end
end

%melhor dia
if dia == best_julho

    if Pmax_2016(i)>0
    n_p_per_hour_best_jul(q) = (Load_hora_A10*100+Load_vents)/Pmax_2016(i);
    end
    
    q=q+1;
    if q ==24
        q=0;
    end
end
end    





if n==8
%---------------
%AGOSTO
%---------------

%ver dia atual
chr_dia = chr(7:8);
dia = str2num(['uint8(',chr_dia,')']);

%pior dia
if dia == worst_agosto

    if Pmax_2016(i)>0
    n_p_per_hour_worst_ago(q) = (Load_hora_A10*100+Load_vents)/Pmax_2016(i);
    end
    
    q=q+1;
    if q==24
        q=0;
    end
end

%melhor dia
if dia == best_agosto

    if Pmax_2016(i)>0
    n_p_per_hour_best_ago(q) = (Load_hora_A10*100+Load_vents)/Pmax_2016(i);
    end
    
    q=q+1;
    if q ==24
        q=0;
    end
end
end  





if n==9
%---------------
%SETEMBRO
%---------------

%ver dia atual
chr_dia = chr(7:8);
dia = str2num(['uint8(',chr_dia,')']);

%pior dia
if dia == worst_setembro

    if Pmax_2016(i)>0
    n_p_per_hour_worst_set(q) = (Load_hora_A10*100+Load_vents)/Pmax_2016(i);
    end
    
    q=q+1;
    if q==24
        q=0;
    end
end

%melhor dia
if dia == best_setembro

    if Pmax_2016(i)>0
    n_p_per_hour_best_set(q) = (Load_hora_A10*100+Load_vents)/Pmax_2016(i);
    end
    
    q=q+1;
    if q ==24
        q=0;
    end
end
end  







if n==10
%---------------
%OUTUBRO
%---------------

%ver dia atual
chr_dia = chr(7:8);
dia = str2num(['uint8(',chr_dia,')']);

%pior dia
if dia == worst_outubro

    if Pmax_2016(i)>0
    n_p_per_hour_worst_out(q) = (Load_hora_A10*100+Load_vents)/Pmax_2016(i);
    end
    
    q=q+1;
    if q==24
        q=0;
    end
end

%melhor dia
if dia == best_outubro

    if Pmax_2016(i)>0
    n_p_per_hour_best_out(q) = (Load_hora_A10*100+Load_vents)/Pmax_2016(i);
    end
    
    q=q+1;
    if q ==24
        q=0;
    end
end
end







if n==11
%---------------
%NOVEMBRO
%---------------

%ver dia atual
chr_dia = chr(7:8);
dia = str2num(['uint8(',chr_dia,')']);

%pior dia
if dia == worst_novembro

    if Pmax_2016(i)>0
    n_p_per_hour_worst_nov(q) = (Load_hora_A10*100+Load_vents)/Pmax_2016(i);
    end
    
    q=q+1;
    if q==24
        q=0;
    end
end

%melhor dia
if dia == best_novembro

    if Pmax_2016(i)>0
    n_p_per_hour_best_nov(q) = (Load_hora_A10*100+Load_vents)/Pmax_2016(i);
    end
    
    q=q+1;
    if q ==24
        q=0;
    end
end
end 






if n==12
%---------------
%DEZEMBRO
%---------------

%ver dia atual
chr_dia = chr(7:8);
dia = str2num(['uint8(',chr_dia,')']);

%pior dia
if dia == worst_dezembro

    if Pmax_2016(i)>0
    n_p_per_hour_worst_dez(q) = (Load_hora_A10*100+Load_vents)/Pmax_2016(i);
    end
    
    q=q+1;
    if q==24
        q=0;
    end
end

%melhor dia
if dia == best_dezembro

    if Pmax_2016(i)>0
    n_p_per_hour_best_dez(q) = (Load_hora_A10*100+Load_vents)/Pmax_2016(i);
    end
    
    q=q+1;
    if q ==24
        q=0;
    end
end
end

end



%% CUSTOS DE INVESTIMENTO TOTAL INICIAL (paineis e mining rig)

%TUDO EM EURO!!
preco_A10 = 3415.12;
preco_LG = 342.54;
preco_elec_grid = 0.05624299; %(0.06616823 USD kWh)
preco_inverter = 2284; %HUAWEI 17K
preco_combiner_box = 144.04;
preco_energy_meter = 295;
preco_DC_breaker = 32.78;
preco_AC_breaker = 27.57;
preco_load_panel = 59.88;
preco_ac_disconnect = 12.74;

%PROFITS:
profit_A10_s_pv = 0.353967; %profit a pagar eletricidade por hora
profit_A10_c_pv = 0.41021; %profit sem pagar eletricidade por hora
preco_venda_grid = 0.05624299/4; %por cada kWh (1/4 do pre�o de venda)


%Ajuste paineis solares devido � eficiencia do inverter e cabos n�o ser 100%
eff_inverter = 0.983;
eff_cabos = 0.99982;
% N_paineis_ajuste_eff = ceil(N_paineis_total/(eff_inverter*eff_cabos));
custo_total_paineis = N_paineis_total*preco_LG;


%C�lculo do n� de Inverters, combiner boxes,breaker boxes and ac breakers
%n� inverters
%16 em s�rie e 2 em paralelo por mppt
%como existem 2 mppt's -> 64 paineis LG por inverter

N_inverters = floor(N_paineis_total/68);

N_combiner_box = 2*N_inverters;

N_DC_breaker_box = N_combiner_box;

N_AC_breaker_box = N_inverters;

N_energy_meter = N_inverters;

N_load_panel = N_inverters;

N_ac_disconnect = N_inverters;

%CUSTOS MINERS & EQUIPAMENTO RESTANTE:
N_miners = 100;
custo_total_miners_A10 = N_miners * preco_A10;
custo_total_inverters = N_inverters * preco_inverter;
custo_total_combiner_box = N_combiner_box * preco_combiner_box;
custo_total_DC_breakers = N_DC_breaker_box * preco_DC_breaker;
custo_total_AC_breakers = N_AC_breaker_box * preco_AC_breaker;
custo_total_energy_meters = N_energy_meter * preco_energy_meter;
custo_total_load_panel = N_load_panel* preco_load_panel;
custo_total_ac_disconnect = N_ac_disconnect* preco_ac_disconnect;

Custo_total_equipamento = custo_total_miners_A10 + custo_total_inverters + custo_total_combiner_box + custo_total_DC_breakers + custo_total_AC_breakers + custo_total_energy_meters + custo_total_load_panel + custo_total_ac_disconnect;   

%CUSTOS ADICIONAIS DE OPERA��O
N_vents = N_inverters;
custo_vents = 46.22*N_vents;
custo_roof_coating = 211.97;
custo_tubagem_A10 = 8.49 * 2 * N_miners;
custo_tubagem_vents = 6.80*N_vents;
custo_terreno_kvareli = 16783.57; %terreno com 10327 metros quadrados
custo_construcao = 70000;
custo_adicional_de_operacoes = custo_vents + custo_roof_coating + custo_tubagem_A10 + custo_tubagem_vents + custo_terreno_kvareli +custo_construcao;

custos_PROJETO_A10 = custo_total_paineis + custo_adicional_de_operacoes + Custo_total_equipamento;


%% Potencia vendida e comprada

%caracteristicas das mining rigs escolhidas:
%A10 Pro ETH Miner 
Load_hora_A10 = 950; %[W]
Load_vents = 135*N_vents;
Pload = Load_hora_A10*100 + Load_vents;
Pcomprada = zeros(1,8773);
Pvendida = zeros(1,8773);

for i=1:8783
    dif = Pload - Pmax_2016(i)*N_paineis_total;
    
    if dif>0 %compro energia
        Pcomprada(i) = dif;
    end
    
     if dif<0 %vendo energia
        Pvendida(i) = dif;
    end
end
figure(6)
plot(Pcomprada)
hold on
plot(Pvendida)
xlabel('horas do ano')
ylabel('Pot�ncia [W]')
title('Pot�ncia comprada e vendida � Grid/ LG /hourly data for 2016')
legend('Comprada','Vendida')


%% AN�LISE CUSTOS TOTAIS DO PROJETO ---> MINING RIG(A10):

%Ajuda da GRID sempre que n�o houver luz solar ou n�o se produza suficiente
%Venda de energia � rede caso se produza a mais

Load_hora_A10 = 950; %W por hora
Load_vents = 135*N_vents; %W por hora
Pload = Load_hora_A10*100 + Load_vents;
Profit_hourly_2016 = zeros(1,8773);
Custos_vents_hourly_2016 = zeros(1,8773);

for i=1:8783
    
    if Pmax_2016(i)*N_paineis_total == 0 %noite
        Profit_hourly_2016(i) = profit_A10_s_pv*N_miners;
        Custos_vents_hourly_2016(i) = Load_vents*(10^-3)*preco_elec_grid;
    else
    %dia
    
    dif = Pload - Pmax_2016(i)*N_paineis_total;
    
    if dif>0 %compro energia (energia a menos)
        
        N_rigs_alimentadas_solar = (Pmax_2016(i)*N_paineis_total)/(Load_hora_A10);
        if N_rigs_alimentadas_solar<N_miners 
            Profit_hourly_2016(i) = (N_rigs_alimentadas_solar*profit_A10_c_pv) + ((N_miners-N_rigs_alimentadas_solar)*profit_A10_s_pv);
            Custos_vents_hourly_2016(i) = Load_vents*(10^-3)*preco_elec_grid;
        end
        if N_rigs_alimentadas_solar==N_miners 
            Profit_hourly_2016(i) = profit_A10_c_pv*N_miners;
            Custos_vents_hourly_2016(i) = Load_vents*(10^-3)*preco_elec_grid;
        end 
        if N_rigs_alimentadas_solar>N_miners 
            Profit_hourly_2016(i) = profit_A10_c_pv*N_miners;
            N_vents_alimentadas_solar = ((Pmax_2016(i)*N_paineis_total)-Load_hora_A10*N_miners)/135;
            Custos_vents_hourly_2016(i) = (N_vents-N_vents_alimentadas_solar)*135*(10^-3)*preco_elec_grid;
        end          
   end
          
    if dif<=0 %vendo energia (energia a mais)
        Profit_hourly_2016(i) = profit_A10_c_pv*N_miners;
        Custos_vents_hourly_2016(i) = 0;
    end 
    end
end


profit_PROJETO_A10 = sum(Profit_hourly_2016);
profit_venda_grid = sum(Pvendida*(-1)*(10^-3)*preco_venda_grid);
profit_PROJETO_A10 = profit_PROJETO_A10 + profit_venda_grid;
vent_costs_projeto = sum(Custos_vents_hourly_2016);

custos_PROJETO_A10 = custos_PROJETO_A10 + vent_costs_projeto;
payback_period_PROJETO_A10 = custos_PROJETO_A10/profit_PROJETO_A10;
display(payback_period_PROJETO_A10)
display(custos_PROJETO_A10 )

%TESTES SEM PAINEIS DO PROFIT DE 100 RIGS
%(100)
profit_teste = profit_A10_s_pv*24*366*N_miners; 
custos_vents_sem_pv = (135*N_vents*24*366*(10^-3)*preco_elec_grid);
custos_teste_projeto_A10 = custo_total_miners_A10 + custos_vents_sem_pv + custo_adicional_de_operacoes;
payback_period_s_pv_teste = custos_teste_projeto_A10/profit_teste;


dif_profit = profit_PROJETO_A10-profit_teste;
dif_payback = payback_period_PROJETO_A10 - payback_period_s_pv_teste;
dif_profit_percentual = dif_profit/profit_teste*100;
display(dif_profit)
display(dif_payback) 
display(dif_profit_percentual) 
%% OTIMIZAR NUMERO DE PAINEIS
% 
% for aux=1:1000
% preco_A10 = 3415.12;
% preco_LG = 342.54;
% preco_elec_grid = 0.05624299; %(0.06616823 USD kWh)
% preco_inverter = 2284; %HUAWEI 17K
% preco_combiner_box = 144.04;
% preco_energy_meter = 295;
% preco_DC_breaker = 32.78;
% preco_AC_breaker = 27.57;
% preco_load_panel = 59.88;
% preco_ac_disconnect = 12.74;
% 
% %PROFITS:
% profit_A10_s_pv = 0.353967; %profit a pagar eletricidade por hora
% profit_A10_c_pv = 0.41021; %profit sem pagar eletricidade por hora
% preco_venda_grid = 0.05624299/4; %por cada kWh (1/4 do pre�o de venda)
% 
% 
% %Ajuste paineis solares devido � eficiencia do inverter e cabos n�o ser 100%
% eff_inverter = 0.983;
% eff_cabos = 0.99982;
% % N_paineis_ajuste_eff = ceil(N_paineis_total/(eff_inverter*eff_cabos));
% 
% 
% 
% %C�lculo do n� de Inverters, combiner boxes,breaker boxes and ac breakers
% %n� inverters
% %16 em s�rie e 2 em paralelo por mppt
% %como existem 2 mppt's -> 64 paineis LG por inverter
% 
% N_inverters = floor(aux/68);
% 
% N_paineis_ajuste_eff = N_inverters*68;
% 
% N_combiner_box = 2*N_inverters;
% 
% N_DC_breaker_box = N_combiner_box;
% 
% N_AC_breaker_box = N_inverters;
% 
% N_energy_meter = N_inverters;
% 
% N_load_panel = N_inverters;
% 
% N_ac_disconnect = N_inverters;
% 
% %CUSTOS MINERS & EQUIPAMENTO RESTANTE:
% N_miners = 100;
% custo_total_miners_A10 = 100 * preco_A10;
% custo_total_inverters = N_inverters * preco_inverter;
% custo_total_combiner_box = N_combiner_box * preco_combiner_box;
% custo_total_DC_breakers = N_DC_breaker_box * preco_DC_breaker;
% custo_total_AC_breakers = N_AC_breaker_box * preco_AC_breaker;
% custo_total_energy_meters = N_energy_meter * preco_energy_meter;
% custo_total_load_panel = N_load_panel* preco_load_panel;
% custo_total_ac_disconnect = N_ac_disconnect* preco_ac_disconnect;
% 
% Custo_total_equipamento = custo_total_miners_A10 + custo_total_inverters + custo_total_combiner_box + custo_total_DC_breakers + custo_total_AC_breakers + custo_total_energy_meters + custo_total_load_panel + custo_total_ac_disconnect;   
% 
% %CUSTOS ADICIONAIS DE OPERA��O
% custo_vents = 46.22*N_inverters;
% custo_roof_coating = 211.97;
% custo_tubagem_A10 = 8.49 *200;
% custo_tubagem_vents = 6.80*N_inverters;
% custo_terreno_kvareli = 16783.57; %terreno com 10327 metros quadrados
% custo_construcao = 70000;
% custo_adicional_de_operacoes = custo_vents + custo_roof_coating + custo_tubagem_A10 + custo_tubagem_vents + custo_terreno_kvareli +custo_construcao;
% custo_total_paineis = N_paineis_ajuste_eff*preco_LG;
% 
% custos_PROJETO_A10 = custo_total_paineis + custo_adicional_de_operacoes + Custo_total_equipamento;
% 
% 
% 
% %caracteristicas das mining rigs escolhidas:
% %A10 Pro ETH Miner 
% Load_hora_A10 = 950; %[W]
% Load_5_vent = 135*N_inverters;
% Pload = Load_hora_A10*100 + Load_5_vent;
% Pcomprada = zeros(1,8773);
% Pvendida = zeros(1,8773);
% 
% for i=1:8783
%     dif = Pload - Pmax_2016(i)*N_paineis_ajuste_eff;
%     
%     if dif>0 %compro energia
%         Pcomprada(i) = dif;
%     end
%     
%      if dif<0 %vendo energia
%         Pvendida(i) = dif;
%     end
% end
% 
% 
% 
% Load_hora_A10 = 950; %W por hora
% Load_5_vent = 135*N_inverters; %W por hora
% Pload = Load_hora_A10*100 + Load_5_vent;
% Profit_hourly_2016 = zeros(1,8773);
% Custos_vents_hourly_2016 = zeros(1,8773);
% 
% for i=1:8783
%     
%     if Pmax_2016(i)*N_paineis_ajuste_eff == 0 %noite
%         Profit_hourly_2016(i) = profit_A10_s_pv*100;
%         Custos_vents_hourly_2016(i) = Load_5_vent*(10^-3)*preco_elec_grid;
%     else
%     %dia
%     
%     dif = Pload - Pmax_2016(i)*N_paineis_ajuste_eff;
%     
%     if dif>0 %compro energia (energia a menos)
%         
%         N_rigs_alimentadas_solar = (Pmax_2016(i)*N_paineis_ajuste_eff)/(Load_hora_A10);
%         if N_rigs_alimentadas_solar<100 
%             Profit_hourly_2016(i) = (N_rigs_alimentadas_solar*profit_A10_c_pv) + ((100-N_rigs_alimentadas_solar)*profit_A10_s_pv);
%             Custos_vents_hourly_2016(i) = Load_5_vent*(10^-3)*preco_elec_grid;
%         end
%         if N_rigs_alimentadas_solar==100 
%             Profit_hourly_2016(i) = profit_A10_c_pv*100;
%             Custos_vents_hourly_2016(i) = Load_5_vent*(10^-3)*preco_elec_grid;
%         end 
%         if N_rigs_alimentadas_solar>100 
%             Profit_hourly_2016(i) = profit_A10_c_pv*100;
%             N_vents_alimentadas_solar = ((Pmax_2016(i)*N_paineis_ajuste_eff)-Load_hora_A10*100)/135;
%             Custos_vents_hourly_2016(i) = (N_inverters-N_vents_alimentadas_solar)*135*(10^-3)*preco_elec_grid;
%         end          
%    end
%           
%     if dif<=0 %vendo energia (energia a mais)
%         Profit_hourly_2016(i) = profit_A10_c_pv*100;
%         Custos_vents_hourly_2016(i) = 0;
%     end 
%     end
% end
% 
% 
% profit_PROJETO_A10 = sum(Profit_hourly_2016);
% profit_venda_grid = sum(Pvendida*(-1)*(10^-3)*preco_venda_grid);
% profit_PROJETO_A10 = profit_PROJETO_A10 + profit_venda_grid;
% vent_costs_projeto = sum(Custos_vents_hourly_2016);
% 
% custos_PROJETO_A10 = custos_PROJETO_A10 + vent_costs_projeto;
% payback_period_PROJETO_A10 = custos_PROJETO_A10/profit_PROJETO_A10;
% 
% 
% if  custos_PROJETO_A10>500000 || payback_period_PROJETO_A10>2
%     fprintf('n_paineis otimizado SHARP:%d \n',aux-1)
%     break
% end
% 
% end


%% Plots adicionais

disp('THE END!')








